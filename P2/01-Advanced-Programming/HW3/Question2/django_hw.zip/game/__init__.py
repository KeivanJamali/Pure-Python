def profile(request, username):


    elif request.method == "PUT":


        try:
            player = Player.objects.get(username=username)
            player.username = request.POST.get("username", player.username)
            player.password = request.POST.get("password", player.password)
            player.age = request.POST.get("age", player.age)
            player.email = request.POST.get("email", player.email)
            player.save()
            return JsonResponse({})
        except Player.DoesNotExist:
            return JsonResponse({}, status=404)
    else:
        return JsonResponse({}, status=405)